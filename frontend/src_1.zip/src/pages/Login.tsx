import { useState } from 'react';
import { Eye, EyeOff, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Input from '../components/Input';
import Button from '../components/Button';
import { API } from '../lib/utils';

export default function Login() {
  const [email, setEmail]   = useState('');
  const [pw, setPw]         = useState('');
  const [show, setShow]     = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState('');
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      const res  = await fetch(`${API}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: pw }), credentials: 'include' });
      const data = await res.json();
      if (!res.ok) { setError(data.message || 'Invalid credentials'); setLoading(false); return; }
      localStorage.setItem('token', data.jwtToken);
      localStorage.setItem('user',  JSON.stringify(data.email));
      const sRes  = await fetch(`${API}/user/subjects`, { headers: { Authorization: `Bearer ${data.jwtToken}` } });
      const sData = await sRes.json();
      navigate(!sData.subjects?.length ? '/subjects' : '/dashboard');
    } catch { setError('Something went wrong. Please try again.'); }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--bg)' }}>
      <div className="w-full max-w-[400px]">
        <div className="text-center mb-8">
          <div className="inline-flex w-11 h-11 rounded-xl items-center justify-center mb-4" style={{ background: 'var(--primary)' }}>
            <Zap className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text)' }}>Welcome back</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Sign in to continue to StudyAI</p>
        </div>
        <div className="auth-card">
          {error && <div className="mb-4 p-3 rounded-lg text-sm font-medium" style={{ background: 'var(--error-light)', color: 'var(--error)', border: '1px solid var(--error-border)' }}>{error}</div>}
          <form onSubmit={submit} className="space-y-4">
            <Input type="email" label="Email address" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
            <div className="relative">
              <Input type={show ? 'text' : 'password'} label="Password" placeholder="Your password" value={pw} onChange={e => setPw(e.target.value)} required />
              <button type="button" onClick={() => setShow(v => !v)} className="absolute right-3 bottom-[0.65rem]" style={{ color: 'var(--muted)' }}>
                {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className="text-right">
              <button type="button" onClick={() => navigate('/forgot-password')} className="text-sm link">Forgot password?</button>
            </div>
            <Button type="submit" fullWidth loading={loading} size="lg">Sign in</Button>
          </form>
        </div>
        <p className="text-center text-sm mt-5" style={{ color: 'var(--muted)' }}>
          No account? <button onClick={() => navigate('/register')} className="link">Create one</button>
        </p>
      </div>
    </div>
  );
}
